# Hanoi Tower Project

The projects,tower of Hanoi is a mathematical puzzle where we have three rods and n disks.
The objective of the puzzle is to move the entire stack to another rod.

## Steps to Run Project

Step 1: Click "Make Move" button to make a disk to move one rod to another.

Step 2: Click "Make Move" button until its get finished.

## Future improvements

The Project is enhanced with more complexity of time and improving algorithm for computing the shortest path.
